
import java.util.InputMismatchException;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author zeidy
 */
public class CodigoMorse {
    
    public static void main(String[]args){
        String[] morse={" .- "," -... "," -.-. "," -.. "," . "," ..-. "," --. "," .... "," .. "," .--- "," -.- "," .-.. "," -- "," -. "," --- "," .--. "," --.- "," .-. "," ... "," - "," ..- "," ...- "," .-- "," -..- "," -.-- "," --.. "," .---- "," ..--- ","...-- "," ....- "," ..... "," -.... "," --... "," ---.. "," ----. "," ----- "};
        String[] abcdario={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","1","2","3","4","5","6","7","8","9","0"};
        
        
        boolean fin=false;
        Scanner s=new Scanner(System.in);
        int op=0;
        
        
        System.out.println("Bienvenido al traductor de codigo morse");
        
        do{
           
           System.out.println("Ingresar una opcion");
           System.out.println("1.Español a morse");
           System.out.println("2.Morse a español");
           System.out.println("3.Salir");
           op= comprobarDatoEnteroIngresado(s,1,3);
           s.nextLine(); 
           fin= procesarOpcion(op,s, abcdario, morse);
            
        }while(!fin);
        
    
    }
    
    
    public static boolean procesarOpcion(int op, Scanner s, String[] abcdario, String[] morse){
        //boolean termina= false;
        if(op==1){
            System.out.println("ingresa frase a traducir");
            String frase= s.nextLine();
            String fraseATraducir = frase.toUpperCase();
            //System.out.println(frase);
            String mensajeTraducido = fraseMorse(fraseATraducir,abcdario, morse);
            System.out.println("Traduccion del mensaje a codigo morse: ");
            System.out.println(mensajeTraducido);
        }else if(op==2){
            System.out.println("ingresa frase a traducir en morse");
            String frase= s.nextLine();
            String mensajeTraducido =morseFrase(frase,abcdario, morse);
            System.out.println("Traduccion al español: ");
            System.out.println(mensajeTraducido);
        }else if(op==3){
            //Salir
            //termina= true;
            return true;
        }
        //return termina;
        return false;
    }

    public static int comprobarDatoEnteroIngresado(Scanner s, int min, int max){
        int valor=0;
        boolean error=false;
        do{
            error = false;
            try{
                valor= s.nextInt();
                if(!((valor>=min)&&(valor<=max))){
                    System.out.println("valor mal ingresado");
                    System.out.println("el valor debe estar entre "+ min+" y "+max);
                    error=true;
                }
                
            }catch(InputMismatchException e){
                System.out.println("Tipo de dato mal ingresado, se esperaba  un numero");
                error=true;
                s.nextLine();
            }catch(Exception e){
                System.out.println("Error inesperado: "+ e);
            }
                 
        
    }while(error);
    return valor;
    
 }

    private static String morseFrase(String fraseATraducir, String[] abcdario, String[] morse) {
        
        String mensajeEspañol = "";
        String caracterMorse = "";
        int i=0;
      
        do{
            boolean terminaCaracter = false;
            do{
                if(Character.toString(fraseATraducir.charAt(i)).equals(" ")){
                    terminaCaracter= true;
                }else{
                    caracterMorse+=Character.toString(fraseATraducir.charAt(i));
                    i++;
                }
            }while((!terminaCaracter)&&(i<fraseATraducir.length()));
            
            int j=0;
            boolean  termina= false;

            do{
                if(caracterMorse.equals(morse[j])){
                    mensajeEspañol += abcdario[j];
                    termina= true;
                }
                j++;
                
                if(j==morse.length){
                    if(!termina){
                        termina=true;
                    }
                }
            }while(!termina);

            caracterMorse="";
            i++;
            
            try{
               
             if(Character.toString(fraseATraducir.charAt(i)).equals(" ")){
                 if(Character.toString(fraseATraducir.charAt(i+1)).equals(" ")){
                     mensajeEspañol += " ";
                     i+=2;
            }
            }
            }catch(StringIndexOutOfBoundsException e){
                
            }catch(Exception e){
                
            }
        }while(i<fraseATraducir.length());
    
        
       
        return mensajeEspañol;
        
    }
    
    private static String fraseMorse(String fraseATraducir, String[] abcdario, String[] morse) {
        
        String mensajeMorse = "";
        
        for(int i=0; i<fraseATraducir.length();i++){
           
            int j=0;
            boolean  termina= false;
            if(Character.toString(fraseATraducir.charAt(i)).equals(" ")){
                mensajeMorse+= "  ";
            }else{
            
            do{
                if(Character.toString(fraseATraducir.charAt(i)).equals(abcdario[j])){
                    mensajeMorse += morse[j] + " ";
                    termina= true;
                }
                j++;
                
                if(j==abcdario.length){
                    if(!termina){
                        termina=true;
                    }
                }
            }while(!termina);

            }
            
        }
        return mensajeMorse;
        
    }
}
